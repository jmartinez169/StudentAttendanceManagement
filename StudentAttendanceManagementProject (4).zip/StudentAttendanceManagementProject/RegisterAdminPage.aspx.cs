﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Data.Common;
using System.Data.OleDb;
using System.Threading.Tasks;


namespace StudentAttendanceManagementProject
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\User\Documents\Visual Studio 2012\Projects\StudentAttendanceManagementProject\StudentAttendanceManagementProject\App_Data\Database1.mdf;Integrated Security=True");

            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT Login (Id, Name, Password) Value ('" + TextBox3.Text + "''" + TextBox1.Text +"' '" + TextBox4.Text + "'", conn);
            new SqlCommand ("INSERT Attendance (Id, Scode) Value ('" + TextBox3.Text + "' '" + TextBox5.Text +"'",conn);
            new SqlCommand("INSERT Instructor (InstructorID, Scode) Value ('" + TextBox6.Text + "''" + TextBox5.Text + "'", conn);
            new SqlCommand("INSERT Student (Name, EID) Value ('" + TextBox1.Text + "''" + TextBox2.Text + "'", conn);

            SqlDataReader reader = cmd.ExecuteReader();

           reader.Close();
            
           int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
            if ((OBJ > 0))
            {
                Response.Redirect("InstructorPage.aspx"); 
            }
            else
            {
            }

            conn.Close();
        }
    }
}