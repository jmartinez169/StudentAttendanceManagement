﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;



namespace StudentAttendanceManagementProject
{
    public partial class Attendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\User\Documents\Visual Studio 2012\Projects\StudentAttendanceManagementProject\StudentAttendanceManagementProject\App_Data\Database1.mdf;Integrated Security=True");

                conn.Open();
                SqlCommand comm = new SqlCommand("select Id,Date,Hour,Scode,RollNo,Attaendance from Attendance", conn);
                comm.ExecuteReader();
                conn.Close();
                SqlDataAdapter da = new SqlDataAdapter(comm);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowEdit(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            BindGridData();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdatedEventArgs e)
        {
            string s= GridView1.DataKeys[e.RowIndex].Value.ToString();
            Label Id = GridView1.Rows[e.RowIndex].FindControl("Id") as Label;
            TextBox Date = GridView1.Rows[e.RowIndex].FindControl("txtDate") as TextBox;
            TextBox Hour = GridView1.Rows[e.RowsIndex].FindContol("txtHour") as TextBox;
            TextBox Scode = GridView1.Rows[e.RowIndex].FindControl("txtScode") as TextBox;
            TextBox RollNo = GridView1.Rows[e.RowIndex].FindControl("txtRollNo") as TextBox;
            TextBox Attendance = GridView1.Rows[e.RowIndex].FindControl("txtAttendance") as TextBox;
            String UpdateQuery = string.Format("UPDATE Attendance SET Attendance = '" + Attendance.Text + " ,RollNo='" + RollNo.Text + " ,Scode ='" + Scode.Text + " ,Hour+'" + Hour + " ,Date ='" + Date.Text + "' WHERE Id='" + Id.Text + "'");
            GridView1.EditIndex = -1;
            BindGridData(UpdateQuery);

        }

        private void BindGridData(string Query)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\User\Documents\Visual Studio 2012\Projects\StudentAttendanceManagementProject\StudentAttendanceManagementProject\App_Data\Database1.mdf;Integrated Security=True");
            
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand(Query + ";select Id,Date,Hour,Scode,RollNo,Attendace from Attendance ", conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(comm);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                }
            }
        }


        protected void GridView1_RowCancelling(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            BindGridData();
        }

        protected void GridView1_RowDeleting( object sender, GridViewDeletedEventArgs e)
        {
            string Id = GridView1.DataKeys[e.RowIndex].Value.ToString();
            string Query = "delete Attendance where Id = " + Id;
            BindGridData(Query);
        }


        private void BindGridData()
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\User\Documents\Visual Studio 2012\Projects\StudentAttendanceManagementProject\StudentAttendanceManagementProject\App_Data\Database1.mdf;Integrated Security=True"))
             
            {
                conn.Open();
                using (SqlCommand comm = new SqlCommand("select Id,Date,Hour,Scode,RollNo,Attendance from Attendance ", conn))
            {
                SqlDataAdapter da = new SqlDataAdapter(comm);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            }
        }
            
            
            protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}