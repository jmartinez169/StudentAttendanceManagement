﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data.OleDb;
using System.Windows;





namespace StudentAttendanceManagementProject
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SignIn_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\User\Documents\Visual Studio 2012\Projects\StudentAttendanceManagementProject\StudentAttendanceManagementProject\App_Data\Database1.mdf;Integrated Security=True");

            conn.Open();
            SqlCommand cmd = new SqlCommand("select COUNT(*) FROM Login WHERE Id='" + LoginTextBox.Text + "' and Password='" + PasswordTextBox.Text + "'", conn);
            SqlDataReader reader = cmd.ExecuteReader();  
            
            reader.Close();
            int OBJ = Convert.ToInt32(cmd.ExecuteScalar());
            if (OBJ > 0)
            {
                Session["Sign In"] = LoginTextBox;
                Response.Redirect("InstructorPage.aspx");
            }
            else
            {
              

            }
            
            conn.Close();
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            Response.Redirect("RegisterAdminPage.aspx");
        }

      
    }
}