﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Common;
using System.Text;
using System.Data;
using System.Data.SqlClient;


namespace StudentAttendanceManagementProject
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\User\Documents\Visual Studio 2012\Projects\StudentAttendanceManagementProject\StudentAttendanceManagementProject\App_Data\Database1.mdf;Integrated Security=True");
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("LogInPage.aspx");
        }

        protected void ResultFewest_Click(object sender, EventArgs e)
        {
           

            conn.Open();
             SqlCommand comm = new SqlCommand("SELECT (Attendance, ID) FROM Attendance WHERE Attandance=Present", conn);
             comm.ExecuteReader(); 
             conn.Close();
             
            
           
            
           
        }

        protected void ResultMost_Click(object sender, EventArgs e)
        {
            String str = "SELECT (Attendance, ID) From Attendance WHERE Attandance=Absent";
            SqlCommand xp = new SqlCommand(str, conn);
            xp.Parameters.Add("@search", SqlDbType.NVarChar).Value = Student1Result.Text;

            conn.Open();
            xp.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = xp;
            DataSet ds = new DataSet();
            da.Fill(ds, "Attendance, ID");
            Student1Result.DataSource = ds;
            GridView.DataBind();
            conn.Close();


            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT (Attendance, ID) FROM Attendance WHERE Attandance=Absent", conn);


            conn.Close();
            
        }
    }
}